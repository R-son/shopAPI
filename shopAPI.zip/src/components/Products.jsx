import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Products.css';

export default function Products() {
    const [products, setProducts] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetch("https://fakestoreapi.com/products", {
            method: "GET",
        })
        .then(res => res.json())
        .then(data => setProducts(data))
        .catch(error => console.error(error));
    }, []);

    const handleClick = (productId) => {
        const product = products.find(p => p.id === productId);
        console.log("Product clicked:", product); // Log product object before navigation
        navigate(`/products/${productId}`, { state: product });
    };    

    return (
        <div className="products-wrapper">
            {products.map(product => (
                <div className="products-container" key={product.id} onClick={() => handleClick(product.id)}>
                    <img src={product.image} alt="" />
                    <h5>{product.title}</h5>
                    <h5>{product.price} $</h5>
                </div>
            ))}
        </div>
    );
}
