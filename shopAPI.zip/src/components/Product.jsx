import React, { useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import '../styles/Product.css'; // Import CSS for styling

export default function ProductPage() {
    const { productId } = useParams();
    const product = useLocation().state;
    const [quantity, setQuantity] = useState(1); // State for quantity

    const handleIncrement = () => {
        setQuantity(prevQuantity => prevQuantity + 1);
    };

    const handleDecrement = () => {
        if (quantity > 1) {
            setQuantity(prevQuantity => prevQuantity - 1);
        }
    };

    const handleAddToCart = () => {
        // Implement logic to add product to cart context with quantity
        console.log(`Added ${quantity} ${product.title} to cart.`);
    };

    return (
        <div className="product-page">
            <h1>Product Details</h1>
            {product && (
                <div className="product-details">
                    <img src={product.image} alt={product.title} className="product-image" />
                    <div className="product-info">
                        <h3 className="product-title">{product.title}</h3>
                        <h3 className="product-price">{product.price} $</h3>
                        <div className="quantity-selector">
                            <button onClick={handleDecrement}>-</button>
                            <span>{quantity}</span>
                            <button onClick={handleIncrement}>+</button>
                        </div>
                        <button onClick={handleAddToCart} className="add-to-cart-button">Add to Cart</button>
                    </div>
                </div>
            )}
        </div>
    );
}
