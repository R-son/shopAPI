import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import CartContext from '../contexts/Cart';

const Cart = () => {
    const { cartItems, increaseQuantity, decreaseQuantity } = useContext(CartContext);
    const [error, setError] = useState('');
    const token = localStorage.getItem('authToken');
    const navigate = useNavigate();

    const handleRedirect = () => {
        navigate('/login');
    };

    if (!token) {
        return (
            <div>
                <h1>You are not logged in</h1>
                <button onClick={handleRedirect} className='go-to-login'>Login</button>
            </div>
        )
    }

    return (
        <div>
            {cartItems.map((item) => (
                <div key={item.productId}>
                    <p>{item.title}</p>
                    <p>Quantity: {item.quantity}</p>
                    <button onClick={() => increaseQuantity(item.productId)}>+</button>
                    <button onClick={() => decreaseQuantity(item.productId)}>-</button>
                </div>
            ))}
        </div>
    );
};

export default Cart;